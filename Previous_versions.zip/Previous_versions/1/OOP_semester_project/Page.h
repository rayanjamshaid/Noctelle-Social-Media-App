#pragma once

#include"User.h"
#include"Post.h"


class Page
{
	static int id_initialiser;
private:
	int id;
	string title;
	User* author;
	Post** posts;
	int post_count;
	int likers;
public:
	Page(User*page_author,string page_title);
	~Page();
	void liked();
	void disliked();
	void add_post(Post* page_post);
};

int Page::id_initialiser = 1;