#include "User.h"



void User::add_friend(string friend_id)
{
	stringstream ss(friend_id);
	int f_id;
	ss >> f_id;
	add_int_to_list(this->friends, this->friend_count, f_id);
}

void User::add_page(string page_id)
{
	stringstream ss(page_id);
	int p_id;
	ss >> p_id;
	add_int_to_list(this->pages, this->page_count, p_id);
}

void User::add_friend(int friend_id)
{
	add_int_to_list(this->friends, this->friend_count, friend_id);
}

void User::add_page(int page_id)
{
	add_int_to_list(this->pages, this->page_count, page_id);
}

void User::add_int_to_list(int* &list, int &length, int to_add)
{
	int* temp = new int[length + 1];
	for (int i = 0; i < length; i++)
	{
		temp[i] = list[i];
	}
	temp[length] = to_add;
	length++;
	delete[]list;
	list = temp;
}

User::User(string user_name) :id(id_initialiser++), name(user_name),friend_count(0),page_count(0),friends(nullptr),pages(nullptr)
{
	string line;

	//reading file for friends
	ifstream fr("user_friends.txt");
	int line_id = 0;
	while (getline(fr, line))
	{
		stringstream ss(line);
		ss >> line_id;
		if (line_id == this->id)
		{
			string friend_id;
			while (getline(ss,friend_id,','))
			{
				add_friend(friend_id);
			}
			break;
		}
		
	}
	fr.close();


	ifstream fr("user_pages.txt");
	line_id = 0;
	while (getline(fr, line))
	{
		stringstream ss(line);
		ss >> line_id;
		if (line_id == this->id)
		{
			string page_id;
			while (getline(ss, page_id, ','))
			{
				add_page(page_id);
			}
			break;
		}

	}
	fr.close();
}

User::~User()
{
	delete[]this->friends;
	delete[]this->pages;
}
