#pragma once
#include<string>
#include<fstream>
#include<sstream>
#include<cstring>

#include"Post.h"
#include"Page.h"

using namespace std;


class User
{
private:
	static int id_initialiser;
	int id;
	string name;
	int* friends;
	int* pages;
	int friend_count;
	int page_count;
	void add_friend(string friend_id);
	void add_page(string page_id);
public:
	
	void add_friend(int friend_id);
	void add_page(int page_id);
	static void add_int_to_list(int* &list, int &length, int to_add);
	User(string user_name="");
	~User();
};

int User::id_initialiser = 1;