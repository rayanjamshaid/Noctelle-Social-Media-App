#pragma once

#include"User.h"
#include"Page.h"
#include"Activity.h"
#include"comment.h"
class Post
{
	static int id_initialiser;
private:
	int id;
	string description;
	int likes;//likes is also likers count
	string content;
	int* likers;
	string* comments;
	int comment_count;
	Activity activity;


public:
	Post(string post_description="",string post_content="");
	~Post();

	void comment(string post_comment);
	void like(int user_id);
};

int Post::id_initialiser = 1;