#pragma once
#include"Post.h"


class Memory
{
private:
	Post* post;
public:
	Memory(Post* post_ptr=nullptr);
	~Memory();

};

