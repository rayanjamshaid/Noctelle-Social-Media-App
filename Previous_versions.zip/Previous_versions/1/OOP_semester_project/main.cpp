#include<iostream>

#include"User.h"
#include"Page.h"
#include"Post.h"


using namespace std;

int main()
{

	return 0;
}