#include "memory.h"

Memory::Memory(Post* post_ptr=nullptr):post(post_ptr)
{
}

Memory::~Memory()
{
}
