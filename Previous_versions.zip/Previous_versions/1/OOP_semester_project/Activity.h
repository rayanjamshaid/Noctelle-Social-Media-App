#pragma once
#include<string>
using namespace std;


class Activity
{
private:
	string type;
	string value;
public:
	Activity(int type_choice=0,string activity_value="");
	~Activity();
	
};

