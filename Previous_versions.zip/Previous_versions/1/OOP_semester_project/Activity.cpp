#include "Activity.h"

Activity::Activity(int type_choice, string activity_value)
{
	switch (type_choice)
	{
	case 0:this->type = ""; break;
	case 1:this->type = "feeling"; break;
	case 2:this->type = "thinking about"; break;
	case 3:this->type = "making"; break;
	case 4:this->type = "celebrating"; break;
	}
	this->value = activity_value;
}

Activity::~Activity()
{
}
