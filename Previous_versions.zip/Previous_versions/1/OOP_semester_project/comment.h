#pragma once
class comment
{
private:
	
};

