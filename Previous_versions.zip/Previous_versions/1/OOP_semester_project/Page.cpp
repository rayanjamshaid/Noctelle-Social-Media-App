#include "Page.h"


Page::Page(User* page_author,string page_title):author(page_author),id(id_initialiser++),title(page_title),posts(nullptr),likers(0),post_count(0)
{
}

Page::~Page()
{
	delete author;
	delete[]posts;
}

void Page::liked()
{
	this->likers++;
}

void Page::disliked()
{
	this->likers--;
}

void Page::add_post(Post* page_post)
{
	Post** temp = new Post * [this->post_count + 1];
	for (int i = 0; i < post_count; i++)
	{
		temp[i] = this->posts[i];

	}
	temp[post_count] = page_post;
	delete[]this->posts;
	this->posts = temp;
	this->post_count++;
}
