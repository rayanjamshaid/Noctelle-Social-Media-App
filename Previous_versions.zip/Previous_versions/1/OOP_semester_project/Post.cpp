#include "Post.h"

Post::Post(string post_description, string post_content):id(id_initialiser++),description(post_description),
likes(0),content(post_content),likers(nullptr),comments(nullptr),comment_count(0)
{
}

Post::~Post()
{
	delete[]likers;
	delete[]comments;
}

void Post::comment(string post_comment)
{
	if (comment_count <= 10)
	{
		string* temp = new string[this->comment_count + 1];
		for (int i = 0; i < this->comment_count; i++)
		{
			temp[i] = this->comments[i];
		}
		temp[this->comment_count] = post_comment;
		delete[]this->comments;
		this->comments = temp;
		comment_count++;
	}
}

void Post::like(int user_id)
{
	int* temp = new int[likes + 1];
	for (int i = 0; i < this->likes; i++)
	{
		temp[i] = this->likers[i];
	}
	temp[likes] = user_id;
	delete[]this->likers;
	this->likers = temp;
	likes++;
}

