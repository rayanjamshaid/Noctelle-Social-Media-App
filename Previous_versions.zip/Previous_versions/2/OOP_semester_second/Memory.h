#pragma once
#include"Post.h"

class Memory
{
private:
	Post* post;
public:
	Memory(Post*& _post);
	~Memory();
};

