#include"App.h"

int main()
{
	App app;
	
	app.run();


	system("pause");
	return 0;
}