#pragma once

#include"Post.h"
#include"User.h"


class Pages
{
private:
	int id;
	User* owner;
	string title;
	Array<Post> posts;
	int like_count;


	void add_post_list();
	bool page_found(int _id, string& _title);
	void register_page();

	int getLastLineInteger(string filename);
public:
	Pages(int _id);
	~Pages();

	//make a function to add post to page
	
};

