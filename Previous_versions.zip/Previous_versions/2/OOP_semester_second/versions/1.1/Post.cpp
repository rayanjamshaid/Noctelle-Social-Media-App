#include "Post.h"


Post::Post(int _id, string _text, Array<int> _likers, Date _date, int _likes = 0)
	:id(_id), text(_text), likers(_likers), date(_date), likes(_likes)
{
}

Post::Post(const Post& other)
{
}

Post::~Post()
{
}

void Post::add_comment(string content)
{
	if(!this->comment_list.add_comment(content))
	{
		cout << "error\n";
	}
}
