#pragma once

#include"Date.h"
#include"Array.h"
#include"Comment.h"

class Post
{
private:
	int id;
	string text;
	int likes;
	Array<int>likers;
	Date date;

	Comment comment_list;
public:

	//make copy constructor
	Post(int _id,string _text,Array<int>_likers,Date _date,int _likes=0);
	Post(const Post& other);
	~Post();


	void add_comment(string content);
};

