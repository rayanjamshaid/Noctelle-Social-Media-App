#pragma once
#include<string>
#include<iostream>
using namespace std;

class Activity
{
private:
	string type;
	string value;
public:
	Activity(int _type);
	~Activity();
};

