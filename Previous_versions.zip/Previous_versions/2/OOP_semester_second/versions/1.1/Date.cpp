#include "Date.h"

Date::Date(int _d, int _m, int _y):d(_d),m(_m),y(_y)
{
}

Date::Date(const Date& other)
{
	this->d = other.d;
	this->m = other.m;
	this->y = other.y;
}

Date& Date::operator=(const Date& other)
{
	if (this != &other)
	{
		this->d = other.d;
		this->m = other.m;
		this->y = other.y;
	}
	return *this;
}

Date::~Date()
{
}

ostream& operator<<(ostream& out, const Date& obj)
{
	out << obj.d << "/" << obj.m << "/20" << obj.y << endl;
	return out;
}
