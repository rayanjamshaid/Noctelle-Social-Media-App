#pragma once

#include<string>
#include<iostream>
#include"Array.h"


using namespace std;
class Comment {
private:
	Array<string>comm;
public:
	Comment();
	bool add_comment(string content);
	~Comment();
};