#pragma once
#include"Pages.h"
#include"Array.h"
#include<string>
#include<cstring>
#include<fstream>
#include<sstream>
#include<iostream>

using namespace std;

class User
{
	
private:
	int id;
	string user_name;


	Array<int> friends;
	Array<int> pages;//pages are liked_pages


	//double helping functions
	int getLastLineInteger(string filename);

	//helping functions
	
	bool user_found(const int _id,string& _user_name);//check if user is in registered_users.txt
	void register_user(int& _id, string& _user_name);
	void add_friend_list(string _user_name,Array<int>& _friends);
	void add_pages_list(string _user_name, Array<int>& _pages);

	

public:
	User(int _id);
	~User();

	string get_username();
	int get_id();

	void add_friend(int _id);
	void like_page(int _id);

	void UserMenu();
};
