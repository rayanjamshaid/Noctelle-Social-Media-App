#include "Comment.h"

Comment::Comment():comm()
{

}

bool Comment::add_comment(string content)
{
	if (this->comm.getlength() < 10)
	{
		comm.push(content);
		return true;
	}
	else
	{
		cout << "error, no more comments";
		return false;
	}
}

Comment::~Comment()
{
}
