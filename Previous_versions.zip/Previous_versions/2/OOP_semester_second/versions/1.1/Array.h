#pragma once
template<typename T>
class Array
{
private:
	int size;
	T* arr;
protected:

public:
	Array();
	Array(const Array& other);
	Array& operator=(const Array& other);
	Array(int _size);
	~Array();

	void push(T obj);
	void pop();

	T& operator[](int index);
	void del(int index);

	int getlength();
};

template<typename T>
inline Array<T>::Array():size(0),arr(nullptr)
{
}

template<typename T>
inline Array<T>::Array(const Array& other)
{
	this->size = other.size;
	this->arr = new T[this->size];
	for (int i = 0; i < size; i++)
	{
		this->arr[i] = other.arr[i];
	}
}

template<typename T>
inline Array<T>& Array<T>::operator=(const Array& other)
{
	if (this != &other)
	{
		this->size = other.size;
		delete this->arr;
		this->arr = new T[this->size];
		for (int i = 0; i < size; i++)
		{
			this->arr[i] = other.arr[i];
		}
	}
	return *this;
}

template<typename T>
inline Array<T>::Array(int _size)
{
	this->size = _size;
	this->arr = new T[size];
}

template<typename T>
inline Array<T>::~Array()
{
	delete[]arr;
}

template<typename T>
inline void Array<T>::push(T obj)
{
	T* temp = new T[this->size + 1];
	for (int i = 0; i < this->size; i++)
	{
		temp[i] = this->arr[i];
	}
	temp[this->size] = obj;
	this->size++;
	delete[]this->arr;
	this->arr = temp;
}

template<typename T>
inline void Array<T>::pop()
{
	T* temp = new T[this->size - 1];
	for (int i = 0; i < this->size-1; i++)
	{
		temp[i] = this->arr[i];
	}
	this->size--;
	delete[]this->arr;
	this->arr = temp;
}

template<typename T>
inline T& Array<T>::operator[](int index)
{
	try
	{
		if (index >= 0 && index < this->size)
		{
			return this->arr[index];
		}
		else throw exception("out of range");
	}
	catch (exception e)
	{
		
	}
}

template<typename T>
inline void Array<T>::del(int index)
{
	try
	{
		if (index >= 0 && index < size)
		{
			T* temp = new T[size - 1];
			for (int i = 0, j = 0; i < size; i++, j++)
			{
				if (i == index)
				{
					j--;
					continue;
				}
				else
				{
					temp[j] = this->arr[i];
				}
			}
			delete[]this->arr;
			this->arr = temp;
			size--;
		}
		else
			throw exception("out of range error");
	}
	catch (exception e)
	{

	}
}

template<typename T>
inline int Array<T>::getlength()
{
	return this->size;
}
