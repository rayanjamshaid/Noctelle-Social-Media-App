#include "Pages.h"




void Pages::add_post_list()
{
	string filepath = "./page_posts/" + this->title + "_posts.txt";
	ifstream fr(filepath);
	fr >> this->like_count;
	string line;
	while (getline(fr, line))
	{
		stringstream sr(line);
		/*id likes date text, l i k e r s*/


		int id;
		string text;
		int likes;
		Array<int>likers;
		int d, int m, int y;
		sr >> id >> likes >> d >> m >> y;
		getline(sr, text, ',');
		int liker_temp;
		while (sr>>liker_temp)
		{
			likers.push(liker_temp);
		}
		this->posts.push(Post(id, text, likers, Date(d, m, y), likes));
	}
	fr.close();
}

bool Pages::page_found(int _id, string& _title)
{
	string line;
	ifstream fr("./existing_pages.txt");
	while (getline(fr, line))
	{
		int temp_id;
		stringstream sr(line);
		sr >> temp_id;
		if (temp_id == _id)
		{
			sr >> _title;
			fr.close();
			return true;

		}
	}

	fr.close();
	return false;
}

void Pages::register_page()
{
	string filepath = "./page_posts/" + this->title + "_posts.txt";
	ofstream fw(filepath);
	fw.close();
}

int Pages::getLastLineInteger(string filename)
{
	ifstream file(filename, ios::ate); // Open the file and seek to the end
	if (!file.is_open()) {
		return -1; // Error indicator
	}

	string lastLine;
	char ch;
	file.seekg(-1, ios::end); // Go to the end of the file
	while (file.tellg() > 0) {
		file.seekg(-2, ios::cur); // Move two steps back
		file.get(ch);
		if (ch == '\n') break; // Stop when a newline is found
	}
	getline(file, lastLine); // Read the last line

	file.close();

	// Extract the integer at the beginning
	int firstInt;
	istringstream iss(lastLine);
	iss >> firstInt;

	return firstInt;
}

Pages::Pages(int _id)
{
	/*
		*okay,1. check if page exists in file called existing_pages
		* 2. if exists, go to ./page_posts/title_posts.txt and load all posts//the first line is no.of likes, and oncoming will be post data
		* 3. if does not exist, make it
		*/
	/*id, text, likes, likers, date*/
	if (page_found(_id, this->title))
	{
		this->id = _id;
		add_post_list();
	}
	else
	{
		cout << "page not found, wanna make the page?";
		bool yes;
		cin >> yes;
		if (yes)
		{
			cout << "enter title :";
			string t;
			getline(cin, t);
			this->title = t;
			
			this->id = this->getLastLineInteger("./existing_pages.txt")+1;
			this->register_page();
		}
	}
}

Pages::~Pages()
{
}
