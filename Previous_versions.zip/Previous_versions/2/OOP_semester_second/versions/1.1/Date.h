#pragma once
#include<iostream>

using namespace std;


class Date
{
	
private:
	int d;
	int m;
	int y;

public:

	friend ostream& operator<<(ostream& out, const Date& obj);

	Date(int _d = 0, int _m = 0, int _y = 0);
	Date(const Date& other);
	Date& operator=(const Date& other);
	~Date();

};

