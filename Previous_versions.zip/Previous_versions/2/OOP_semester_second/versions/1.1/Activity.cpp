#include "Activity.h"

Activity::Activity(int _type)
{
	switch (_type)
	{
	case 1:this->type = "feeling"; break;
	case 2:this->type = "thinking about"; break;
	case 3:this->type = "making"; break;
	case 4:this->type = "celebrating"; break;
	}
	cout << "Enter your " << this->type << " : ";
	getline(cin, this->value);

}

Activity::~Activity()
{
}
