#pragma once

#include"Date.h"
#include"Array.h"
#include"Comment.h"
#include"Activity.h"

#include<iostream>
using namespace std;

class Post
{
	//friend ostream& operator<<(ostream& out, const Post& obj);
private:
	int id;
	string text;
	int likes;
	Array<int>likers;
	Date date;
	Activity act;

	Comment comment_list;
public:

	//make copy constructor
	Post(int _id,string _text,Array<int>_likers,Date _date,int _likes=0,string activity_type="",string activity_value="");
	Post(const Post& other);
	Post& operator=(const Post& other);
	~Post();

	
	void print_post();
	void add_comment(string content);
};

