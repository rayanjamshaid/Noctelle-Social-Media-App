#include "Post.h"


Post::Post(int _id, string _text, Array<int> _likers, Date _date, int _likes = 0, string activity_type = "", string activity_value = "")
	:id(_id), text(_text), likers(_likers), date(_date), likes(_likes), act(activity_type, activity_value)
{
}

Post::Post(const Post& other)
{
	this->act = other.act;
	this->comment_list = other.comment_list;
	this->date = other.date;
	this->id = other.id;
	this->likers = other.likers;
	this->likes = other.likes;
	this->text = other.text;
}

Post& Post::operator=(const Post& other)
{
	if (this != &other)
	{
		this->act = other.act;
		this->comment_list = other.comment_list;
		this->date = other.date;
		this->id = other.id;
		this->likers = other.likers;
		this->likes = other.likes;
		this->text = other.text;
	}
	return *this;
}

Post::~Post()
{
}



void Post::print_post()
{
	cout << this->id << endl << this->text << endl << this->likes << " <3    posted on" << this->date << endl;
	this->comment_list.print_comments();
	cout << "Liked by :";
	int length = this->likers.getlength();
	for (int i = 0; i < length; i++)
	{
		cout << "u" << this->likers[i] << " ";

	}
	cout << endl;
}

void Post::add_comment(string content)
{
	if(!this->comment_list.add_comment(content))
	{
		cout << "error\n";
	}
}


