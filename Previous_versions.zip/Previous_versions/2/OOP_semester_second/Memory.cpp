#include "Memory.h"

Memory::Memory(Post*& _post):post(_post)
{
}

Memory::~Memory()
{
}
