#pragma once
#include<string>
#include<iostream>
using namespace std;

class Activity
{
	friend ostream& operator<<(ostream& out, const Activity& obj);
private:
	string type;
	string value;
public:
	Activity(int _type);
	Activity(string _type = "", string _value = "");

	Activity(const Activity& other);
	Activity& operator=(const Activity& other);

	~Activity();
};

