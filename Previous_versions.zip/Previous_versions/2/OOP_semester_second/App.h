#pragma once

#include"User.h"
#include"Date.h"
#include"Helper.h"
#include"Pages.h"
#include"Post.h"
#include<iostream>
#include<fstream>
#include<string>
#include<cstring>

using namespace std;


class App
{
private:
	User current;
	Array<User>users;
	Array<Post>anonymous_posts;
	Array<Pages>all_pages;

	Date today;


	
	void initialise_users();
	void initialise_pages();
	void initialise_anonymous_posts();
public:
	App();
	~App();

	void run();
};

