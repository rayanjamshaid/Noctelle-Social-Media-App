#pragma once

#include"Post.h"
#include"User.h"


class Pages:public Helper
{
private:
	int id;
	User* owner;
	string title;
	Array<Post> posts;
	int like_count;


	void add_post_list();
	bool page_found(int _id, string& _title);
	void register_page();

	
public:
	Pages(int _id);
	~Pages();
	Pages(const Pages& other);
	Pages& operator=(const Pages& other);
	//make a function to add post to page
	void add_post(int id, int likes, int d, int m, int y, string text,
		string activity_type, string activity_value, Array<int>& likers);

	void print_posts();
	
};

