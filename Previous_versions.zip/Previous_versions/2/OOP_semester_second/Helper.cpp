#include "Helper.h"


int Helper::getLastLineInteger(string filename)
{
	ifstream file(filename, ios::ate); // Open the file and seek to the end
	if (!file.is_open()) {
		return -1; // Error indicator
	}

	string lastLine;
	char ch;
	file.seekg(-1, ios::end); // Go to the end of the file
	while (file.tellg() > 0) {
		file.seekg(-2, ios::cur); // Move two steps back
		file.get(ch);
		if (ch == '\n') break; // Stop when a newline is found
	}
	getline(file, lastLine); // Read the last line

	file.close();

	// Extract the integer at the beginning
	int firstInt;
	istringstream iss(lastLine);
	iss >> firstInt;

	return firstInt;
}

void Helper::add_post_record(string filename, int id, int likes, int d, int m, int y, string text, string activity_type, string activity_value, Array<int>& likers)
{
	/*id likes date text,activity type,activity value, l i k e r s*/
	ofstream fw(filename, ios::app);
	fw << id << " " << likes << " " << d << " " << m << " " << y << " " << text << "," << activity_type << "," << activity_value << ",";
	int length = likers.getlength();
	for (int i = 0; i < length; i++)
	{
		fw << likers[i] << " ";
	}
	fw.close();
}
