#include "Comment.h"

Comment::Comment():comm()
{

}

Comment::Comment(const Comment& other)
{
	this->comm = other.comm;
}

Comment& Comment::operator=(const Comment& other)
{
	if (this != &other)
	{
		this->comm = other.comm;
	}
	return *this;
}

void Comment::print_comments()
{
	int length = this->comm.getlength();
	for (int i = 0; i < length; i++)
	{
		cout << "--------" << this->comm[i] << endl;
	}
}

bool Comment::add_comment(string content)
{
	if (this->comm.getlength() < 10)
	{
		comm.push(content);
		return true;
	}
	else
	{
		cout << "error, no more comments";
		return false;
	}
}

Comment::~Comment()
{
}


