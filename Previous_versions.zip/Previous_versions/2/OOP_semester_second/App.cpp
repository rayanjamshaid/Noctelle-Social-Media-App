#include "App.h"

void App::initialise_users()
{
	ifstream fr("./registered_users.txt");
	string line;
	while (getline(fr, line))
	{
		int id;
		stringstream sr(line);
		sr >> id;
		this->users.push(User(id));
	}
	fr.close();
}

void App::initialise_pages()
{
	ifstream fr("./existing_pages.txt");
	string line;
	while (getline(fr, line))
	{
		stringstream ss(line);
		int id;
		ss >> id;
		this->all_pages.push(Pages(id));
	}
	fr.close();
}

void App::initialise_anonymous_posts()
{
	string filepath = "./anonymous_posts.txt";
	ifstream fr(filepath);
	string line;
	while (getline(fr, line))
	{
		stringstream sr(line);
		/*id likes date text,activity type,activity value, l i k e r s*/

		int id;
		string text, activity_type, activity_value;
		int likes;
		Array<int>likers;
		int d, m, y;
		sr >> id >> likes >> d >> m >> y;
		getline(sr, text, ',');
		getline(sr, activity_type, ',');
		getline(sr, activity_value, ',');
		int liker_temp;
		while (sr >> liker_temp)
		{
			likers.push(liker_temp);
		}
		this->anonymous_posts.push(Post(id, text, likers, Date(d, m, y), likes, activity_type, activity_value));
	}
	fr.close();
}

App::App():current(),users(),anonymous_posts(),all_pages(),today()
{
	cout << "enter date (use spaces) in format day/month/year:  ";
	int d, m, y;
	cin >> d >> m >> y;

	today.init_date(d, m, y);

	void initialise_users();
	void initialise_pages();
	void initialise_anonymous_posts();

	cout << "Enter your user unique id\nif want to add new user, input 0 :";
	cin >> d;
	current.init_user(d);
}

App::~App()
{
}

void App::run()
{
	
	while (1)
	{
		static int posts_printed = false;
		if (!posts_printed)
		{
			int length = this->anonymous_posts.getlength();
			for (int i = 0; i < length; i++)
			{
				this->anonymous_posts[i].print_post();
				cout << endl << endl;
			}

			this->current.print_friend_pages(this->all_pages);



			posts_printed = true;
		}


		//cout << "1.like a post\n2.view likers of post\n3.comment on post\n
		// 4.view post\n5.share a memory

		cout << "1. view user profile\n"
			<< "2. view friend list of a user\n"
			<< "3. view page \n"
			<< "4. view page menu\n"
			<< "5. view anonymous posts\n"
			<< "6. view anonymous posts menu\n"
			<< "7. share memory : ";

			


		int option = 0;
		cin >> option;
		switch (option)
		{
		case 1: {
			cout << "enter user id: ";
			int id;
			cin >> id;
			this->users[id].print_user_profile();
		}break;
		case 2: {
			cout << "enter user id: ";
			int id;
			cin >> id;
			this->users[id].view_friend_list(this->users);
		}break;
		case 3:{
			cout << "enter id of page : ";
			int id;
			cin >> id;
			this->all_pages[id].print_posts();
		}break;
		case 4:break;
		case 5: {
			int length = this->anonymous_posts.getlength();
			for (int i = 0; i < length; i++)
			{
				this->anonymous_posts[i].print_post();
			}
		}break;
		case 6:break;
		case 7:break;
		case 8:break;
		}
	}
}
