#include "Activity.h"

Activity::Activity(int _type)
{
	switch (_type)
	{
	case 1:this->type = "feeling"; break;
	case 2:this->type = "thinking about"; break;
	case 3:this->type = "making"; break;
	case 4:this->type = "celebrating"; break;
	}
	cout << "Enter your " << this->type << " : ";
	getline(cin, this->value);

}

Activity::Activity(string _type, string _value)
{
	this->type = type;
	this->value = _value;
}

Activity::Activity(const Activity& other)
{
	this->type = other.type;
	this->value = other.value;
}

Activity& Activity::operator=(const Activity& other)
{
	if (this != &other)
	{
		this->type = other.type;
		this->value = other.value;
	}
	return *this;
}

Activity::~Activity()
{
}

ostream& operator<<(ostream& out, const Activity& obj)
{
	out << obj.type << "  " << obj.value << "  ";
	return out;
}
