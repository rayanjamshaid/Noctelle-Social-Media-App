#include "Pages.h"




void Pages::add_post_list()
{
	string filepath = "./page_posts/" + this->title + "_posts.txt";
	ifstream fr(filepath);
	fr >> this->like_count;
	string line;
	while (getline(fr, line))
	{
		stringstream sr(line);
		/*id likes date text,activity type,activity value, l i k e r s*/


		int id;
		string text, activity_type, activity_value;
		int likes;
		Array<int>likers;
		int d, m, y;
		sr >> id >> likes >> d >> m >> y;
		getline(sr, text, ',');
		getline(sr, activity_type, ',');
		getline(sr, activity_value, ',');
		int liker_temp;
		while (sr>>liker_temp)
		{
			likers.push(liker_temp);
		}
		this->posts.push(Post(id, text, likers, Date(d, m, y), likes,activity_type,activity_value));
	}
	fr.close();
}

bool Pages::page_found(int _id, string& _title)
{
	string line;
	ifstream fr("./existing_pages.txt");
	while (getline(fr, line))
	{
		int temp_id;
		stringstream sr(line);
		sr >> temp_id;
		if (temp_id == _id)
		{
			getline(sr, title);
			fr.close();
			return true;

		}
	}

	fr.close();
	return false;
}

void Pages::register_page()
{
	string filepath = "./page_posts/" + this->title + "_posts.txt";
	ofstream fw(filepath);
	fw.close();
}


Pages::Pages(int _id)
{
	/*
		*okay,1. check if page exists in file called existing_pages
		* 2. if exists, go to ./page_posts/title_posts.txt and load all posts//the first line is no.of likes, and oncoming will be post data
		* 3. if does not exist, make it
		*/


	//the format of files "./page_posts/title_posts.txt" is like this
		/*id likes date text,activity type,activity value, l i k e r s*/
	if (page_found(_id, this->title))
	{
		this->id = _id;
		add_post_list();
	}
	else
	{
		cout << "page not found, wanna make the page?";
		bool yes;
		cin >> yes;
		if (yes)
		{
			cout << "enter title :";
			string t;
			getline(cin, t);
			this->title = t;
			
			this->id = Helper::getLastLineInteger("./existing_pages.txt")+1;
			this->register_page();
		}
	}
}

Pages::~Pages()
{
}

Pages::Pages(const Pages& other)
{
	this->id = other.id;
	this->like_count = other.like_count;
	this->owner = other.owner;
	this->posts = other.posts;
	this->title = other.title;
}

Pages& Pages::operator=(const Pages& other)
{
	if (this != &other)
	{
		this->id = other.id;
		this->like_count = other.like_count;
		this->owner = other.owner;
		this->posts = other.posts;
		this->title = other.title;
	}
	return *this;
}

void Pages::add_post(int id, int likes, int d, int m, int y, string text, string activity_type, string activity_value, Array<int>& likers)
{
	string filepath = "./page_posts/" + this->title + "_posts.txt";
	Helper::add_post_record(filepath, id, likes, d, m, y, text, activity_type, activity_value, likers);
}

void Pages::print_posts()
{
	int length = this->posts.getlength();
	for (int i = 0; i < length; i++)
	{
		this->posts[i].print_post();
	}
}
