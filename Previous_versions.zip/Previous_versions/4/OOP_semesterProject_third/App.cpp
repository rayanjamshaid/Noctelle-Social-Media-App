#include "App.h"

void App::initialise_users()
{
    ifstream fr("./registered_users.txt");
    string line;
    while (getline(fr, line))
    {
        int id;
        stringstream sr(line);
        sr >> id;
        this->users.push(User(id));
    }
    fr.close();
}

void App::initialise_pages()
{
    ifstream fr("./existing_pages.txt");
    string line;
    while (getline(fr, line))
    {
        //page_id owner_id title//
        stringstream ss(line);
        int id, owner_id;
        string title;
        ss >> id >> owner_id;
        getline(ss >> std::ws, title);
        getline(ss, title);
        this->all_pages.push(Pages(id,title,&this->users[owner_id]));
    }
    fr.close();
}

void App::initialise_anonymous_posts()
{
    string filepath = "./anonymous_posts.txt";
    ifstream fr(filepath);
    string line;
    while (getline(fr, line))
    {
        stringstream sr(line);
        //id likes d m y text,activity_type,activity_value, l i k e r s
        int id;
        string text, activity_type, activity_value;
        int likes;
        Array<int> likers;
        int d, m, y;
        sr >> id >> likes >> d >> m >> y;
        getline(sr, text, ',');
        getline(sr, activity_type, ',');
        getline(sr, activity_value, ',');
        int liker_temp;
        while (sr >> liker_temp)
        {
            likers.push(liker_temp);
        }
        this->anonymous_posts.push(Post(id, text, likers, Date(d, m, y), likes, activity_type, activity_value));
    }
    fr.close();
}

void App::save_data()
{
    // Save users to file
    ofstream userFile("./registered_users.txt");
    for (int i = 0; i < users.getlength(); i++)
    {
        userFile << users[i].get_id() << endl;  // assuming User class has getUserId()
    }
    userFile.close();

    // Save anonymous posts to file
    ofstream postFile("./anonymous_posts.txt");
    for (int i = 0; i < anonymous_posts.getlength(); i++)
    {
        postFile << anonymous_posts[i].get_id() << " "
            << anonymous_posts[i].getLikes() << " "
            << anonymous_posts[i].getDate().getDay() << " "
            << anonymous_posts[i].getDate().getMonth() << " "
            << anonymous_posts[i].getDate().getYear() << " "
            << anonymous_posts[i].getText() << ","
            << anonymous_posts[i].getActivityType() << ","
            << anonymous_posts[i].getActivityValue() << endl;
    }
    postFile.close();
}

App::App() : current(), users(), anonymous_posts(), all_pages(), today()
{
    cout << "Enter date (day/month/year): ";
    int d, m, y;
    cin >> d >> m >> y;

    today.init_date(d, m, y);


    cout << "Enter your user unique id\nif you want to add a new user, input 0: ";
    cin >> d;
    current.init_user(d);

    initialise_users();
    initialise_pages();
    initialise_anonymous_posts();

    
}

App::~App()
{
    //save_data();  // Save data when app closes
}

void App::run()
{
    while (true)
    {

        static bool posts_printed = false;
        if (!posts_printed)
        {
            cout << "\n\n\n____________MAIN PAGE_____________\n";
            int length = this->anonymous_posts.getlength();
            for (int i = 0; i < length; i++)
            {
                cout << "\n\n-------Post " << i + 1 << "--------\n";
                this->anonymous_posts[i].print_post();
                cout << "\n--------End Post---------\n\n";
            }

            this->current.print_friend_pages(this->all_pages);
            posts_printed = true;
            cout << "__________END MAIN PAGE___________\n";
        }

        cout << "\n1. View user profile\n"
            << "2. View friend list of a user\n"
            << "3. View page\n"
            << "4. Make a page\n"
            << "5. View anonymous posts\n"
            << "6. Share memory\n"
            << "7. Like a post\n"
            << "8. Comment on a post\n"
            << "9. Exit\n"
            << "10. view list of users\n"
            << "11. make friends\n"
            << "12. add a post to some page\n"
            << "13. add a anonymous post\n";

        int option = 0;
        cin >> option;
        switch (option)
        {
        case 1:
        {
            cout << "Enter user id: ";
            int id;
            cin >> id;
            id--;
            this->users[id].print_user_profile();
            this->users[id].view_friend_list(this->users);
            this->users[id].print_friend_pages(this->all_pages);
            
        }break;

        case 2:
        {
            cout << "Enter user id: ";
            int id;
            cin >> id;
            id--;
            this->users[id].view_friend_list(this->users);
        }
        break;

        case 3:
        {
            cout << "Enter page id: ";
            int id;
            cin >> id;
            this->all_pages[id].print_posts();
        }
        break;

        case 4: {
            this->all_pages.push(Pages(0,&current));
            
        }
            break; 
        case 5:
        {
            int length = this->anonymous_posts.getlength();
            for (int i = 0; i < length; i++)
            {
                this->anonymous_posts[i].print_post();
            }
        }
        break;

        case 6:  // Share Memory
        {
            cout << "Share a memory (Enter post ID): ";
            int postId;
            cin >> postId;
            if (postId < anonymous_posts.getlength())
            {
                Memory mem(&this->anonymous_posts[postId]);
                mem.show_memory();
            }
            else
            {
                cout << "Invalid post ID!\n";
            }
        }
        break;

        case 7:  // Like Post
        {
            cout << "Enter post ID to like: ";
            int postId;
            cin >> postId;
            if (postId < anonymous_posts.getlength())
            {
                anonymous_posts[postId].like_post(this->current.get_id());
                cout << "Post liked!\n";
            }
            else
            {
                cout << "Invalid post ID!\n";
            }
        }
        break;

        case 8:  // Comment on Post
        {
            cout << "Enter post ID to comment on: ";
            int postId;
            cin >> postId;
            if (postId < anonymous_posts.getlength())
            {
                string commentText;
                cout << "Enter comment: ";
                cin.ignore(); // Clear any previous input buffer
                getline(cin, commentText);
                anonymous_posts[postId].add_comment(commentText);
            }
            else
            {
                cout << "Invalid post ID!\n";
            }
        }
        break;

        case 9:return;
        case 10:
        {
            for (int i = 0; i < this->users.getlength(); i++)
            {
                this->users[i].print_user_profile();
            }
        }
        break;
        case 11:
        {
            for (int i = 0; i < this->users.getlength(); i++)
            {
                this->users[i].print_user_profile();
            }
            cout << "Who do you want as your friend? :\nEnter his/her user id : ";
            int id = 0;
            cin >> id;
            this->current.add_friend(id);
        }
        break;
        case 12:
        {
            int page_id;
            cout << "enter page_id :";
            cin >> page_id;
            page_id--;
            if (this->current.page_owned(page_id))
            {
                cout << "enter id : ";
                int post_id;
                cin >> post_id;
                cout << "enter text of post : ";
                string text, activity_type, activity_value;
                cin >> text;
                cout << "Enter activity type : ";
                cin >> activity_type;
                cout << "Enter activity value : ";
                cin >> activity_value;
                this->all_pages[page_id].add_post(post_id, 0, this->today, text, activity_type, activity_value);
                /*void add_post(int id, int likes, Date d, std::string text,
        std::string activity_type, std::string activity_value,Array<int>& likers);*/
            }
            else
                cout << "You do not own this page\n";
            //continue it from here tomorrow, so that we can add post functionality, along with date thing..

            //this->all_pages[page_id].add_post()
        }
        break;
        default:
            cout << "Invalid option. Please try again.\n";
        }
    }
}
