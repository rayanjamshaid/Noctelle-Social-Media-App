#pragma once
#include<string>

using namespace std;

class User
{
private:
	int id;
	string name;
	int* friends;
	int friend_count;
	int* pages;
	int page_count;

	void copy_int_array(int length,int*destination,int*source);
public:
	User(int _id=0,string _name="", int* _friends=nullptr, int _friend_count=0, int* _pages=nullptr, int _page_count=0);
	~User();
	User(const User& other);
	User& operator=(const User& other);


};