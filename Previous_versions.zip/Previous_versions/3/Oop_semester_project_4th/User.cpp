#include "User.h"

void User::copy_int_array(int length, int* destination, int* source)
{
	destination = new int[length];
	for (int i = 0; i < length; i++)
	{
		destination[i] = source[i];
	}
}

User::User(int _id=0, string _name="", int* _friends=nullptr, int _friend_count=0, int* _pages=nullptr, int _page_count=0)
	:id(_id),name(_name),friends(_friends),friend_count(_friend_count),
	pages(_pages),page_count(_page_count)
{
}

User::~User()
{
	delete[]friends;
	delete[]pages;
}

User::User(const User& other)
{
	this->id = other.id;
	this->name = other.name;
	this->friend_count = other.friend_count;
	copy_int_array(this->friend_count, this->friends, other.friends);
	this->page_count = other.page_count;
	copy_int_array(this->page_count, this->pages, other.pages);
}

User& User::operator=(const User& other)
{
	if (this != &other)
	{
		this->id = other.id;
		this->name = other.name;
		this->friend_count = other.friend_count;
		copy_int_array(this->friend_count, this->friends, other.friends);
		this->page_count = other.page_count;
		copy_int_array(this->page_count, this->pages, other.pages);
	}
	return *this;
}
