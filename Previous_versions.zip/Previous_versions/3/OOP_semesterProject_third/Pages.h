#pragma once

#include "Post.h"

#include "User.h"
#include "Helper.h"
#include "Array.h"

#include "C_Array.h"

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

class User;


class Pages : public Helper {
private:
    int id;
    User* owner;
    std::string title;

    

    C_Array<Post>posts;
    int like_count;

    void add_post_list();
    bool page_found(int _id, std::string& out_title);
    void register_page();

public:
    Pages(int _id, User* _owner = nullptr); // optional owner
    Pages();
    ~Pages();
    Pages(const Pages& other);
    Pages& operator=(const Pages& other);

    void add_post(int id, int likes, int d, int m, int y, std::string text,
        std::string activity_type, std::string activity_value,
        Array<int>& likers);

    void print_posts();
};
