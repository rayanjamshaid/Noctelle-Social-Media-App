#include"Pages.h"



void Pages::add_post_list() {
    string filepath = "./page_posts/" + this->title + "_posts.txt";
    ifstream fr(filepath);
    if (!fr.is_open()) {
        cerr << "Error opening post list for page: " << title << endl;
        return;
    }

    fr >> this->like_count;
    string line;
    getline(fr, line); // consume newline after like_count

    while (getline(fr, line)) {
        stringstream sr(line);

        int id, likes, d, m, y;
        string text, activity_type, activity_value;
        Array<int> likers;
        sr >> id >> likes >> d >> m >> y;
        sr.ignore(); // ignore whitespace before text
        getline(sr, text, ',');
        getline(sr, activity_type, ',');
        getline(sr, activity_value, ',');

        int liker_temp;
        while (sr >> liker_temp) {
            likers.push(liker_temp);
        }

        posts.push(Post(id, text, likers, Date(d, m, y), likes, activity_type, activity_value));
    }

    fr.close();
}

bool Pages::page_found(int _id, string& out_title) {
    ifstream fr("./existing_pages.txt");
    string line;

    while (getline(fr, line)) {
        stringstream sr(line);
        int temp_id;
        sr >> temp_id;
        if (temp_id == _id) {
            getline(sr, out_title);
            fr.close();
            return true;
        }
    }

    fr.close();
    return false;
}

void Pages::register_page() {
    string filepath = "./page_posts/" + this->title + "_posts.txt";
    ofstream fw(filepath);
    if (fw.is_open()) {
        fw << 0 << endl; // like count line
        fw.close();
    }

    ofstream registerFile("./existing_pages.txt", ios::app);
    if (registerFile.is_open()) {
        registerFile << this->id << " " << this->title << endl;
        registerFile.close();
    }
}

Pages::Pages(int _id, User* _owner) {
    this->owner = _owner;

    string loaded_title;
    if (page_found(_id, loaded_title)) {
        this->id = _id;
        this->title = loaded_title;
        add_post_list();
    }
    else {
        cout << "Page not found. Do you want to create a new one? (1 = Yes, 0 = No): ";
        bool create_new = false;
        cin >> create_new;
        cin.ignore();

        if (create_new) {
            cout << "Enter title: ";
            getline(cin, this->title);

            this->id = Helper::getLastLineInteger("./existing_pages.txt") + 1;
            this->like_count = 0;
            this->register_page();
        }
    }
}

Pages::Pages()
{
}

Pages::~Pages() {
    //posts.clear(); // assuming Array<T> has clear()
    owner = nullptr; // not deleting: we don't own the user
}

Pages::Pages(const Pages& other) {
    this->id = other.id;
    this->like_count = other.like_count;
    this->owner = other.owner;
    this->posts = other.posts;
    this->title = other.title;
}

Pages& Pages::operator=(const Pages& other) {
    if (this != &other) {
        this->id = other.id;
        this->like_count = other.like_count;
        this->owner = other.owner;
        this->posts = other.posts;
        this->title = other.title;
    }
    return *this;
}

void Pages::add_post(int id, int likes, int d, int m, int y, string text,
    string activity_type, string activity_value, Array<int>& likers) {
    if (likers.getlength() > 10) {
        cerr << "Error: Too many likers. Max allowed is 10." << endl;
        return;
    }

    string filepath = "./page_posts/" + this->title + "_posts.txt";
    Helper::add_post_record(filepath, id, likes, d, m, y, text, activity_type, activity_value, likers);
    posts.push(Post(id, text, likers, Date(d, m, y), likes, activity_type, activity_value));
}

void Pages::print_posts() {
    for (int i = 0; i < posts.getlength(); ++i) {
        posts[i].print_post();
    }
}
