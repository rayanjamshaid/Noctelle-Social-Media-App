#include "Comment.h"

Comment::Comment() : comm() {}

Comment::Comment(const Comment& other) {
    comm = other.comm;
}

Comment& Comment::operator=(const Comment& other) {
    if (this != &other) {
        comm = other.comm;
    }
    return *this;
}

void Comment::print_comments() {
    int length = comm.getlength(); 
    for (int i = 0; i < length; i++) {
        cout << "--------" << comm[i] << endl;
    }
}

bool Comment::add_comment(string content) {
    if (comm.getlength() < 10) {
        comm.push(content);
        return true;
    }
    else {
        cout << "Error: No more comments allowed." << endl;
        return false;
    }
}

Comment::~Comment() {}
