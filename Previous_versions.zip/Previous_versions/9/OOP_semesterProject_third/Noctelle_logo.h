﻿#pragma once
#include <iostream>
#include <windows.h>
#include <vector>
#include <cstdlib>
#include <ctime>

class Noctelle {
private:
    HANDLE hConsole;
    void setColor(int color) {
        SetConsoleTextAttribute(hConsole, color);
    }
    void moveCursor(int x, int y) {
        COORD coord;
        coord.X = x;
        coord.Y = y;
        SetConsoleCursorPosition(hConsole, coord);
    }

    // Print the Pakistan flag in ASCII art
    void drawPakistanFlag() {
        int startX = 5, startY = 5;
        int width = 50, height = 20;

        // Flag colors
        int bgColor = 13;    // Light pink (13 is light magenta in Windows console)
        int flagColor = 14;  // Bright yellow (14 is yellow in Windows console)

        // Draw the background (light pink)
        setColor(bgColor);
        for (int y = 0; y < height; ++y) {
            moveCursor(startX, startY + y);
            for (int x = 0; x < width; ++x) {
                std::cout << " ";
            }
        }

        // Draw the crescent (bright yellow)
        setColor(flagColor);
        // Outer circle of crescent
        int centerX = startX + width / 2 - 5;
        int centerY = startY + height / 2;
        int radius = 7;

        for (int y = -radius; y <= radius; ++y) {
            for (int x = -radius; x <= radius; ++x) {
                if (x * x + y * y <= radius * radius) {
                    moveCursor(centerX + x, centerY + y);
                    std::cout << "*";
                }
            }
        }

        // Inner circle (to create crescent effect)
        int innerRadius = 5;
        int innerOffsetX = 3;

        for (int y = -innerRadius; y <= innerRadius; ++y) {
            for (int x = -innerRadius; x <= innerRadius; ++x) {
                if (x * x + y * y <= innerRadius * innerRadius) {
                    moveCursor(centerX + x + innerOffsetX, centerY + y);
                    setColor(bgColor); // Set back to background color
                    std::cout << " ";
                }
            }
        }

        // Draw the star (bright yellow)
        setColor(flagColor);
        int starX = centerX + 10;
        int starY = centerY - 3;

        // Drawing a simple 5-point star
        moveCursor(starX, starY);
        std::cout << "*";
        moveCursor(starX - 1, starY + 1);
        std::cout << "*";
        moveCursor(starX + 1, starY + 1);
        std::cout << "*";
        moveCursor(starX - 2, starY - 1);
        std::cout << "*";
        moveCursor(starX + 2, starY - 1);
        std::cout << "*";

        setColor(7); // Reset color
    }

public:
    Noctelle() {
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    }

    void printFlag() {
        system("cls");
        drawPakistanFlag();

        // Move cursor away from the flag
        moveCursor(0, 30);
    }
};

// Example usage:
// int main() {
//     Noctelle n;
//     n.printFlag();
//     std::cin.get();
//     return 0;
// }