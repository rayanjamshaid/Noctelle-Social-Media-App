#include <iostream>
#include "App.h"
#include "Noctelle_logo.h"

int main() {
    //Noctelle noctelle;
   // noctelle.printFlag(); 

    App app;
    app.run(); // Your app's output

    system("pause");
    return 0;
}
