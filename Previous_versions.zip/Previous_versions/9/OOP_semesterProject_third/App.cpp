#include "App.h"

void App::initialise_users()
{
    ifstream fr("./registered_users.txt");
    string line;
    while (getline(fr, line))
    {
        int id;
        stringstream sr(line);
        sr >> id;
        this->users.push(User(id));
    }
    fr.close();
}

void App::initialise_pages()
{
    ifstream fr("./existing_pages.txt");
    string line;
    while (getline(fr, line))
    {
        //page_id owner_id title//
        stringstream ss(line);
        int id, owner_id;
        string title;
        ss >> id >> owner_id;
        getline(ss >> std::ws, title);
        getline(ss, title);
        owner_id--;
        this->all_pages.push(Pages(id,title,&(this->users[owner_id])));
    }
    fr.close();
}

void App::initialise_anonymous_posts()
{
    string filepath = "./anonymous_posts.txt";
    ifstream fr(filepath);
    string line;
    while (getline(fr, line))
    {
        stringstream sr(line);
        //id likes d m y text,activity_type,activity_value, l i k e r s;c,o,m,m,e,n,t,s,//
        /*
        *
        */
        int id;
        string text, activity_type, activity_value;
        int likes;
        Array<int> likers;
        int d, m, y;
        sr >> id >> likes >> d >> m >> y;
        getline(sr, text, ',');
        getline(sr, activity_type, ',');
        getline(sr, activity_value, ',');
        /* string likers_list;
        getline(sr, likers_list, ';');
        stringstream sr_likers(likers_list);
        int liker_temp;
        while (sr_likers >> liker_temp) {
            likers.push(liker_temp);
        }

        string temp_comment;
        Comment temp_c;
        while (getline(sr, temp_comment, ','))
        {
            temp_c.add_comment(temp_comment);
        }*/


        string likers_list;
        getline(sr, likers_list, ';');
        stringstream sr_likers(likers_list);
        int liker_temp;
        while (sr_likers >> liker_temp) {
            likers.push(liker_temp);
        }

        string temp_comment;
        Comment temp_c;
        while (getline(sr, temp_comment, ','))
        {
            temp_c.add_comment(temp_comment);
        }

        this->anonymous_posts.push(Post(id, text, likers, Date(d, m, y), likes, activity_type, activity_value, temp_c));
    }
    fr.close();
}

void App::save_data()
{
    /*
    // Save users to file
    ofstream userFile("./registered_users.txt");
    for (int i = 0; i < users.getlength(); i++)
    {
        userFile << users[i].get_id() << endl;  // assuming User class has getUserId()
    }
    userFile.close();
    */

    // Save anonymous posts to file
    //id likes d m y text,activity_type,activity_value, l i k e r s;c,o,m,m,e,n,t,s//
    ofstream postFile("./anonymous_posts.txt");
    for (int i = 0; i < anonymous_posts.getlength(); i++)
    {
        postFile << this->anonymous_posts[i] << endl;
    }
    postFile.close();
}

App::App() : current(), users(), anonymous_posts(), all_pages(), today()
{
    cout << "Enter date (day/month/year/hour/min): ";
    int d, m, y,h,min;
    cin >> d >> m >> y>>h>>min;

    today.init_date(d, m, y,h,min);


    cout << "Enter your user unique id\nif you want to add a new user, input 0: ";
    cin >> d;
    current.init_user(d);

    initialise_users();
    initialise_pages();
    initialise_anonymous_posts();

    
}

App::~App()
{
    save_data();  // Save data when app closes
}

void App::run()
{
    while (true)
    {
        static bool posts_printed = false;
        if (!posts_printed)
        {
            cout << "\n\n\n╔══════════════════════════════════╗\n";
            cout << "║           MAIN PAGE             ║\n";
            cout << "╚══════════════════════════════════╝\n";
            
            int length = this->anonymous_posts.getlength();
            bool flag = true;
            for (int i = length-1; i >=0&&true; i--)
            {
                if (this->anonymous_posts[i].is24H(today))
                {
                    cout << "\n┌─────────────────────────────────┐\n";
                    cout << "│          Post " << i + 1;
                    if (i + 1 < 10) cout << "                │\n";
                    else cout << "               │\n";
                    cout << "└─────────────────────────────────┘\n";
                    this->anonymous_posts[i].print_post();
                    cout << "\n┌─────────────────────────────────┐\n";
                    cout << "│          End Post              │\n";
                    cout << "└─────────────────────────────────┘\n";
                }
                else
                {
                    flag = false;
                    break;
                }
            }

            this->current.print_friend_pages(this->all_pages,&today);
            posts_printed = true;
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║        END MAIN PAGE            ║\n";
            cout << "╚══════════════════════════════════╝\n";
        }

        cout << "\n┌─────────────────────────────────┐\n";
        cout << "│          MENU OPTIONS           │\n";
        cout << "├─────────────────────────────────┤\n";
        cout << "│  0. View yourself               │\n";
        cout << "│  1. View user profile           │\n";
        cout << "│  2. View friend list of a user  │\n";
        cout << "│  3. View page                   │\n";
        cout << "│  4. Make a page                 │\n";
        cout << "│  5. View anonymous posts        │\n";
        cout << "│  6. Share memory                │\n";
        cout << "│  7. Like a post                 │\n";
        cout << "│  8. Comment on a post           │\n";
        cout << "│  9. Exit                        │\n";
        cout << "│ 10. View list of users          │\n";
        cout << "│ 11. Make friends                │\n";
        cout << "│ 12. Add post to a page          │\n";
        cout << "│ 13. Add anonymous post          │\n";
        cout << "│ 14. Like a page                 │\n";
        cout << "│ 15. View all pages with owners  │\n";
        cout << "│ 16. View all users              │\n";
        cout << "└─────────────────────────────────┘\n";
        cout << "\nEnter your choice: ";
        
        int option = 0;
        cin >> option;
        switch (option)
        {
        case 0: 
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         YOUR PROFILE            ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "ID: " << this->current.get_id() 
                << "   \tUsername: " << this->current.get_username() << endl;
            this->current.view_friend_list(this->users);
            cout << "\n──────────────────────────────────\n";
        }
        break;
        case 1:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         USER PROFILE            ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Enter user ID: ";
            int id;
            cin >> id;
            id--;
            cout << "\n──────────────────────────────────\n";
            this->users[id].print_user_profile();
            this->users[id].view_friend_list(this->users);
            this->users[id].print_friend_pages(this->all_pages);
            cout << "\n──────────────────────────────────\n";
        }break;

        case 2:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         FRIEND LIST             ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Enter user ID: ";
            int id;
            cin >> id;
            id--;
            this->users[id].view_friend_list(this->users);
            cout << "\n──────────────────────────────────\n";
        }
        break;

        case 3:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║          VIEW PAGE              ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Enter page ID: ";
            int id;
            cin >> id;
            id--;
            cout << "\n──────────────────────────────────\n";
            this->all_pages[id].print_posts();
            cout << "\n──────────────────────────────────\n";
        }
        break;

        case 4: {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║          CREATE PAGE            ║\n";
            cout << "╚══════════════════════════════════╝\n";
            this->all_pages.push(Pages(0,&current));
            cout << "Page created successfully!\n";
            cout << "\n──────────────────────────────────\n";
        }
            break; 
        case 5:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║       ANONYMOUS POSTS           ║\n";
            cout << "╚══════════════════════════════════╝\n";
            int length = this->anonymous_posts.getlength();
            for (int i = 0; i < length; i++)
            {
                cout << "\n┌─────────────────────────────────┐\n";
                cout << "│          Post " << i + 1;
                if (i + 1 < 10) cout << "                │\n";
                else cout << "               │\n";
                cout << "└─────────────────────────────────┘\n";
                this->anonymous_posts[i].print_post();
                cout << endl;
            }
            cout << "\n──────────────────────────────────\n";
        }
        break;

        case 6:  // Share Memory
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         SHARE MEMORY            ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Share a memory (Enter post ID): ";
            int postId;
            cin >> postId;
            if (postId < anonymous_posts.getlength())
            {
                Memory mem(&this->anonymous_posts[postId]);
                mem.show_memory();
            }
            else
            {
                cout << "❌ Invalid post ID!\n";
            }
            cout << "\n──────────────────────────────────\n";
        }
        break;

        case 7:  // Like Post
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║          LIKE POST              ║\n";
            cout << "╚══════════════════════════════════╝\n";
            bool is_page_post;
            cout << "Is this a post inside a Page (1) or an anonymous post (0)?: ";
            cin >> is_page_post;
            if (is_page_post)
            {
                cout << "Enter page ID: ";
                int page_id;
                cin >> page_id;
                page_id--;
                this->all_pages[page_id].like_some_post(this->current.get_id());
            }
            else
            {
                cout << "Enter post ID to like: ";
                int postId;
                cin >> postId;
                postId--;

                if (postId < anonymous_posts.getlength())
                {
                    anonymous_posts[postId].like_post(this->current.get_id());
                    cout << "✅ Post liked successfully!\n";
                }
                else
                {
                    cout << "❌ Invalid post ID!\n";
                }
            }
            cout << "\n──────────────────────────────────\n";
        }
        break;

        case 8:  // Comment on Post
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║        COMMENT ON POST          ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Is the post anonymous (0) or in a page (1)?: ";
            bool opt;
            cin >> opt;
            if (opt)
            {
                cout << "Enter page ID: ";
                int page_id;
                cin >> page_id;
                page_id--;
                this->all_pages[page_id].print_posts();
                cout << "Enter ID of post: ";
                int post_id;
                cin >> post_id;
                cout << "Enter your comment: ";
                cin.ignore();
                string comment_text;
                getline(cin, comment_text);
                this->all_pages[page_id].comment_on_some_post(post_id, comment_text);
                cout << "✅ Comment added successfully!\n";
            }
            else {
                cout << "Enter post ID to comment on: ";
                int postId;
                cin >> postId;
                postId--;
                if (postId < anonymous_posts.getlength())
                {
                    string commentText;
                    cout << "Enter comment: ";
                    cin.ignore();
                    getline(cin, commentText);
                    anonymous_posts[postId].add_comment(commentText);
                    cout << "✅ Comment added successfully!\n";
                }
                else
                {
                    cout << "❌ Invalid post ID!\n";
                }
            }
            cout << "\n──────────────────────────────────\n";
        }
        break;

        case 9:
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║        EXITING PROGRAM          ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Thank you for using the application!\n";
            return;
        case 10:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         LIST OF USERS           ║\n";
            cout << "╚══════════════════════════════════╝\n";
            for (int i = 0; i < this->users.getlength(); i++)
            {
                this->users[i].print_user_profile();
                cout << "──────────────────────────────────\n";
            }
        }
        break;
        case 11:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         MAKE FRIENDS            ║\n";
            cout << "╚══════════════════════════════════╝\n";
            for (int i = 0; i < this->users.getlength(); i++)
            {
                this->users[i].print_user_profile();
                cout << "──────────────────────────────────\n";
            }
            cout << "Who do you want as your friend?\n";
            cout << "Enter their user ID: ";
            int id = 0;
            cin >> id;
            this->current.add_friend(id);
            cout << "✅ Friend added successfully!\n";
            cout << "\n──────────────────────────────────\n";
        }
        break;
        case 12:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║        ADD POST TO PAGE         ║\n";
            cout << "╚══════════════════════════════════╝\n";
            int page_id;
            cout << "Enter page ID: ";
            cin >> page_id;
            page_id--;
            if (this->all_pages[page_id].if_user_owns_page(this->current.get_id()))
            {
                cout << "Enter post ID: ";
                int post_id;
                cin >> post_id;
                cout << "Enter text of post: ";
                string text, activity_type, activity_value;
                cin >> text;
                cout << "Enter activity type: ";
                cin >> activity_type;
                cout << "Enter activity value: ";
                cin >> activity_value;
                this->all_pages[page_id].add_post(post_id, 0, this->today, text, activity_type, activity_value);
                cout << "✅ Post added successfully!\n";
            }
            else
                cout << "❌ You do not own this page!\n";
            cout << "\n──────────────────────────────────\n";
        }
        break;
        case 13:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║       ADD ANONYMOUS POST        ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Enter post ID: ";
            int post_id;
            cin >> post_id;
            cout << "Enter text of post: ";
            string text, activity_type, activity_value;
            cin >> text;
            cout << "Enter activity type: ";
            cin >> activity_type;
            cout << "Enter activity value: ";
            cin >> activity_value;
            Array<int>likeers;
            Comment temp_c;
            this->anonymous_posts.push(Post(post_id, text, likeers, today, 0, activity_type, activity_value,temp_c));
            cout << "✅ Anonymous post added successfully!\n";
            cout << "\n──────────────────────────────────\n";
        }
        break;
        case 14:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║          LIKE A PAGE            ║\n";
            cout << "╚══════════════════════════════════╝\n";
            cout << "Enter the ID of page to like: ";
            int id;
            cin >> id;
            this->current.like_page(id);
            cout << "✅ Page liked successfully!\n";
            cout << "\n──────────────────────────────────\n";
        }
        break;
        case 15:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║    ALL PAGES WITH OWNERS        ║\n";
            cout << "╚══════════════════════════════════╝\n";
            int length = this->all_pages.getlength();
            for (int i = 0; i < length; i++)
            {
                cout << "ID: " << i+1 << "   ";
                this->all_pages[i].print_profile();
                cout << "\n──────────────────────────────────\n";
            }
        }
        break;
        case 16:
        {
            cout << "\n╔══════════════════════════════════╗\n";
            cout << "║         ALL USERS               ║\n";
            cout << "╚══════════════════════════════════╝\n";
            int length = this->users.getlength();
            for (int i = 0; i < length; i++)
            {
                this->users[i].print_user_profile();
                cout << "──────────────────────────────────\n";
            }
        }
        break;
        
        default:
            cout << "\n Invalid option. Please try again.\n";
        }
    }
}